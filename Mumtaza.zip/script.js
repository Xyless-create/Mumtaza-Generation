function showMessage() {
  document.getElementById("specialMessage").innerText = "Semoga Ramadhan kali ini penuh keberkahan dan amalan kita diterima. Aamiin!";
}